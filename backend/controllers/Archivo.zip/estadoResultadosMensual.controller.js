// backend/controllers/estadoResultadosMensual.controller.js
const Ingreso = require("../models/Ingreso");
const Egreso = require("../models/Egreso");

exports.getEstadoMensual = async (req, res) => {
  const { anio } = req.params;

  try {
    const ingresosMensuales = await Ingreso.aggregate([
      {
        $match: {
          fecha: {
            $gte: new Date(`${anio}-01-01`),
            $lte: new Date(`${anio}-12-31`)
          }
        }
      },
      {
        $group: {
          _id: { $month: "$fecha" },
          total: { $sum: "$monto" }
        }
      }
    ]);

    const egresosMensuales = await Egreso.aggregate([
      {
        $match: {
          fecha: {
            $gte: new Date(`${anio}-01-01`),
            $lte: new Date(`${anio}-12-31`)
          }
        }
      },
      {
        $group: {
          _id: { $month: "$fecha" },
          total: { $sum: "$monto" }
        }
      }
    ]);

    const mensual = Array(12).fill(0).map((_, i) => {
      const ingreso = ingresosMensuales.find(m => m._id === i + 1)?.total || 0;
      const egreso = egresosMensuales.find(m => m._id === i + 1)?.total || 0;
      const ebitda = ingreso - egreso;
      return {
        ingresos: ingreso,
        egresos: egreso,
        ebitda,
        flujoCaja: ebitda
      };
    });

    res.json(mensual);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error al obtener el estado mensual." });
  }
};